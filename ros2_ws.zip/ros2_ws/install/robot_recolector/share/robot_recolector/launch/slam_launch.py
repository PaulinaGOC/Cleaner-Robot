#!/usr/bin/env python3
"""
slam_launch.py — ROS2 Jazzy
Lanza:
  1. TF estático base_link -> base_laser
  2. slam_toolbox como LifecycleNode con auto-activación
  3. RViz2
"""
 
from launch import LaunchDescription
from launch_ros.actions import Node, LifecycleNode
from launch.actions import RegisterEventHandler, EmitEvent
from launch.event_handlers import OnProcessStart
from launch_ros.events.lifecycle import ChangeState
from lifecycle_msgs.msg import Transition
from launch.substitutions import LaunchConfiguration
from launch_ros.event_handlers import OnStateTransition
from ament_index_python.packages import get_package_share_directory
import launch
import os
 
 
def generate_launch_description():
 
    slam_params = os.path.join(
        get_package_share_directory('robot_recolector'),
        'config',
        'mapper_params_online_async.yaml'
    )
 
    rviz_config = os.path.join(
        get_package_share_directory('robot_recolector'),
        'config',
        'slam.rviz'
    )
 
    # ── TF estático ──────────────────────────────────────────────────
    static_tf = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='base_to_laser_tf',
        arguments=[
            '--x', '0.0',
            '--y', '0.0',
            '--z', '0.15',
            '--roll', '0.0',
            '--pitch', '0.0',
            '--yaw', '0.0',
            '--frame-id', 'base_link',
            '--child-frame-id', 'base_laser',
        ],
        output='screen',
    )
 
    # ── slam_toolbox como LifecycleNode ──────────────────────────────
    slam_node = LifecycleNode(
        package='slam_toolbox',
        executable='async_slam_toolbox_node',
        name='slam_toolbox',
        namespace='',
        output='screen',
        parameters=[slam_params],
    )
 
    # Configurar slam_toolbox al arrancar
    configure_slam = EmitEvent(
        event=ChangeState(
            lifecycle_node_matcher=launch.events.matches_action(slam_node),
            transition_id=Transition.TRANSITION_CONFIGURE,
        )
    )
 
    # Activar slam_toolbox después de configurar
    activate_slam = RegisterEventHandler(
        OnStateTransition(
            target_lifecycle_node=slam_node,
            goal_state='inactive',
            entities=[
                EmitEvent(
                    event=ChangeState(
                        lifecycle_node_matcher=launch.events.matches_action(slam_node),
                        transition_id=Transition.TRANSITION_ACTIVATE,
                    )
                ),
            ],
        )
    )
 
    # ── RViz2 ────────────────────────────────────────────────────────
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config],
        output='screen',
    )
 
    return LaunchDescription([
        static_tf,
        slam_node,
        configure_slam,
        activate_slam,
        rviz,
    ])
 
