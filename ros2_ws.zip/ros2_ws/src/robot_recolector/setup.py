from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'robot_recolector'

setup(
    name=package_name,
    version='0.0.1',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
         # Launch files
        (os.path.join('share', package_name, 'launch'),
            glob('launch/*.py')),
        # Config files
        (os.path.join('share', package_name, 'config'),
            glob('config/*.yaml') + glob('config/*.rviz')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='chosenone',
    maintainer_email='chosenone@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
        'publisher = robot_recolector.publisher:main',
        'teleop_keyboard = robot_recolector.teleop_keyboard:main',
        'cmdvel_serial = robot_recolector.cmdvel_serial:main', 
        ],
    },
)
