#!/usr/bin/env python3
"""
cmdvel_serial.py — ROS2 Jazzy
Nodo único que maneja TODO el puerto serial:
  - Recibe /cmd_vel -> manda CMD al Arduino
  - Lee ODOM del Arduino -> publica /odom + TF odom->base_link

Un solo proceso = un solo dueño del puerto serial.
"""

import math
import queue
import serial
import threading
import time

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, TransformStamped
from nav_msgs.msg import Odometry
from tf2_ros import TransformBroadcaster

SERIAL_PORT = '/dev/ttyACM0'
BAUD_RATE   = 115200

# Parámetros físicos — deben coincidir con el Arduino
PULSOS_POR_VUELTA = 765.0 * 4.0  # 4x por CHANGE en ISR
RADIO_RUEDA       = 0.03           # metros
BASE_RUEDAS       = 0.36           # metros
LOOP_S            = 0.05           # período Arduino (50ms)


class CmdVelSerial(Node):

    def __init__(self):
        super().__init__('cmdvel_serial')

        # ── Estado cmd_vel ───────────────────────────────────────────
        self._v    = 0.0
        self._w    = 0.0
        self._prev_v = None
        self._prev_w = None
        self._cmd_lock = threading.Lock()

        # ── Estado odometría ─────────────────────────────────────────
        self._x     = 0.0
        self._y     = 0.0
        self._theta = 0.0
        self._vx    = 0.0
        self._wz    = 0.0
        self._prev_encL = None
        self._prev_encR = None
        self._odom_lock = threading.Lock()

        # ── Cola de comandos para el hilo escritor ───────────────────
        self._q = queue.Queue(maxsize=2)

        # ── Puerto serial ────────────────────────────────────────────
        self._ser      = None
        self._ser_lock = threading.Lock()

        # ── ROS2 publishers ──────────────────────────────────────────
        self.odom_pub       = self.create_publisher(Odometry, '/odom', 10)
        self.tf_broadcaster = TransformBroadcaster(self)

        # ── Subscripción cmd_vel ─────────────────────────────────────
        self.create_subscription(Twist, '/cmd_vel', self._cb_cmd_vel, 10)

        # ── Timer: encola CMD a 20Hz ─────────────────────────────────
        self.create_timer(0.05, self._timer_enqueue)

        # ── Timer: publica /odom a 20Hz ──────────────────────────────
        self.create_timer(0.05, self._publish_odom)

        # ── Hilos seriales ───────────────────────────────────────────
        threading.Thread(target=self._open_port,    daemon=True).start()
        threading.Thread(target=self._writer_worker, daemon=True).start()
        threading.Thread(target=self._reader_worker, daemon=True).start()

        self.get_logger().info("cmdvel_serial listo (cmd_vel + odom en un solo nodo)")

    # ────────────────────────────────────────────────────────────────
    # Abrir puerto con reintentos
    # ────────────────────────────────────────────────────────────────
    def _open_port(self):
        while True:
            try:
                ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=0.1)
                time.sleep(2.5)
                ser.reset_input_buffer()
                with self._ser_lock:
                    self._ser = ser
                self.get_logger().info(f"Puerto {SERIAL_PORT} abierto")
                return
            except serial.SerialException as e:
                self.get_logger().error(f"No se pudo abrir puerto: {e} — reintentando")
                time.sleep(1.0)

    # ────────────────────────────────────────────────────────────────
    # Callback /cmd_vel
    # ────────────────────────────────────────────────────────────────
    def _cb_cmd_vel(self, msg: Twist):
        with self._cmd_lock:
            self._v = float(msg.linear.x)
            self._w = float(msg.angular.z)

        if self._v != self._prev_v or self._w != self._prev_w:
            self.get_logger().info(f"cmd_vel -> v={self._v:.3f}  w={self._w:.3f}")
            self._prev_v = self._v
            self._prev_w = self._w

    # ────────────────────────────────────────────────────────────────
    # Timer: mete CMD en cola
    # ────────────────────────────────────────────────────────────────
    def _timer_enqueue(self):
        with self._cmd_lock:
            cmd = f"CMD,{self._v:.3f},{self._w:.3f}\n"
        try:
            self._q.put_nowait(cmd)
        except queue.Full:
            try:
                self._q.get_nowait()
                self._q.put_nowait(cmd)
            except queue.Empty:
                pass

    # ────────────────────────────────────────────────────────────────
    # Hilo escritor: saca de cola y manda al Arduino
    # ────────────────────────────────────────────────────────────────
    def _writer_worker(self):
        while self._ser is None:
            time.sleep(0.1)
        while True:
            try:
                cmd = self._q.get(timeout=0.1)
                with self._ser_lock:
                    ser = self._ser
                if ser and ser.is_open:
                    ser.write(cmd.encode())
                    ser.flush()
            except queue.Empty:
                pass
            except serial.SerialException as e:
                self.get_logger().error(f"Error escritura serial: {e}")
                time.sleep(0.5)

    # ────────────────────────────────────────────────────────────────
    # Hilo lector: lee ODOM y actualiza estado
    # ────────────────────────────────────────────────────────────────
    def _reader_worker(self):
        while self._ser is None:
            time.sleep(0.1)
        while True:
            try:
                with self._ser_lock:
                    ser = self._ser
                if not ser or not ser.is_open:
                    time.sleep(0.1)
                    continue

                line = ser.readline().decode('utf-8', errors='ignore').strip()

                if not line.startswith('ODOM,'):
                    continue

                parts = line.split(',')
                if len(parts) < 8:
                    continue

                x     = float(parts[1])
                y     = float(parts[2])
                theta = float(parts[3])
                encL  = int(parts[4])
                encR  = int(parts[5])

                # Velocidades desde encoders
                with self._odom_lock:
                    if self._prev_encL is not None:
                        dL  = encL - self._prev_encL
                        dR  = encR - self._prev_encR
                        distL = (2.0 * math.pi * RADIO_RUEDA * dL) / PULSOS_POR_VUELTA
                        distR = (2.0 * math.pi * RADIO_RUEDA * dR) / PULSOS_POR_VUELTA
                        self._vx  = ((distL + distR) / 2.0) / LOOP_S
                        self._wz  = ((distR - distL) / BASE_RUEDAS) / LOOP_S

                    self._prev_encL = encL
                    self._prev_encR = encR
                    self._x     = x
                    self._y     = y
                    self._theta = theta

            except Exception as e:
                self.get_logger().warn(f"Error lectura serial: {e}")
                time.sleep(0.1)

    # ────────────────────────────────────────────────────────────────
    # Timer: publica /odom y TF odom->base_link
    # ────────────────────────────────────────────────────────────────
    def _publish_odom(self):
        with self._odom_lock:
            x     = self._x
            y     = self._y
            theta = self._theta
            vx    = self._vx
            wz    = self._wz

        now = self.get_clock().now().to_msg()
        qz  = math.sin(theta / 2.0)
        qw  = math.cos(theta / 2.0)

        # /odom
        odom = Odometry()
        odom.header.stamp    = now
        odom.header.frame_id = 'odom'
        odom.child_frame_id  = 'base_link'

        odom.pose.pose.position.x    = x
        odom.pose.pose.position.y    = y
        odom.pose.pose.position.z    = 0.0
        odom.pose.pose.orientation.x = 0.0
        odom.pose.pose.orientation.y = 0.0
        odom.pose.pose.orientation.z = qz
        odom.pose.pose.orientation.w = qw

        odom.pose.covariance[0]  = 0.05
        odom.pose.covariance[7]  = 0.05
        odom.pose.covariance[35] = 0.1

        odom.twist.twist.linear.x  = vx
        odom.twist.twist.angular.z = wz
        odom.twist.covariance[0]   = 0.05
        odom.twist.covariance[7]   = 0.05
        odom.twist.covariance[35]  = 0.1

        self.odom_pub.publish(odom)

        # TF odom -> base_link
        t = TransformStamped()
        t.header.stamp    = now
        t.header.frame_id = 'odom'
        t.child_frame_id  = 'base_link'
        t.transform.translation.x = x
        t.transform.translation.y = y
        t.transform.translation.z = 0.0
        t.transform.rotation.x = 0.0
        t.transform.rotation.y = 0.0
        t.transform.rotation.z = qz
        t.transform.rotation.w = qw

        self.tf_broadcaster.sendTransform(t)


def main():
    rclpy.init()
    node = CmdVelSerial()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
