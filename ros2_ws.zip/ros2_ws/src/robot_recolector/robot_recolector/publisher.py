#!/usr/bin/env python3
# ==========================================================
# ROS2 Nodo Serial -> /odom + TF
# Lee Arduino por USB serial
#
# Formato esperado desde Arduino:
# ODOM,x,y,theta,rpmL,rpmR,pwmL,pwmR
#
# Ejemplo:
# ODOM,0.5231,0.0142,0.0021,55.10,54.82,143,146
# ==========================================================

import math
import serial

import rclpy
from rclpy.node import Node

from nav_msgs.msg import Odometry
from geometry_msgs.msg import Quaternion, TransformStamped
from tf2_ros import TransformBroadcaster


class SerialOdomNode(Node):

    def __init__(self):
        super().__init__('serial_odom_node')

        # ================= PARAMETROS =================
        self.declare_parameter('port', '/dev/ttyACM0')
        self.declare_parameter('baud', 115200)
        self.declare_parameter('frame_id', 'odom')
        self.declare_parameter('child_frame', 'base_link')

        port = self.get_parameter('port').value
        baud = self.get_parameter('baud').value

        self.frame_id = self.get_parameter('frame_id').value
        self.child_frame = self.get_parameter('child_frame').value

        # ================= SERIAL =================
        self.serial = serial.Serial(port, baud, timeout=0.1)

        # limpiar buffer inicial
        self.serial.reset_input_buffer()

        # ================= ROS2 =================
        self.odom_pub = self.create_publisher(Odometry, '/odom', 10)
        self.tf_broadcaster = TransformBroadcaster(self)

        self.timer = self.create_timer(0.02, self.read_serial)  # 50 Hz

        self.get_logger().info(
            f'Leyendo Arduino en {port} @ {baud}'
        )

    # ==================================================
    # Quaternion desde yaw
    # ==================================================
    def yaw_to_quaternion(self, yaw):
        q = Quaternion()
        q.x = 0.0
        q.y = 0.0
        q.z = math.sin(yaw / 2.0)
        q.w = math.cos(yaw / 2.0)
        return q

    # ==================================================
    # Leer Serial
    # ==================================================
    def read_serial(self):

        try:
            line = self.serial.readline().decode(
                'utf-8',
                errors='ignore'
            ).strip()

            if not line:
                return

            # Debug: mostrar línea recibida
            self.get_logger().info(f'RAW: {line}')

            parts = line.split(',')

            # Validación
            if len(parts) < 8:
                return

            if parts[0].strip() != "ODOM":
                return

            # Parseo
            x = float(parts[1])
            y = float(parts[2])
            theta = float(parts[3])

            rpm_l = float(parts[4])
            rpm_r = float(parts[5])

            pwm_l = int(parts[6])
            pwm_r = int(parts[7])

            # Debug datos útiles
            self.get_logger().info(
                f'x={x:.3f} y={y:.3f} th={theta:.3f} '
                f'rpmL={rpm_l:.1f} rpmR={rpm_r:.1f} '
                f'pwmL={pwm_l} pwmR={pwm_r}'
            )

            self.publish_odom(x, y, theta, rpm_l, rpm_r)

        except Exception as e:
            self.get_logger().warn(f'Error serial: {str(e)}')

    # ==================================================
    # Publicar /odom y TF
    # ==================================================
    def publish_odom(self, x, y, theta, rpm_l, rpm_r):

        now = self.get_clock().now()
        q = self.yaw_to_quaternion(theta)

        # =============== ODOM ==================
        odom = Odometry()

        odom.header.stamp = now.to_msg()
        odom.header.frame_id = self.frame_id
        odom.child_frame_id = self.child_frame

        # Pose
        odom.pose.pose.position.x = x
        odom.pose.pose.position.y = y
        odom.pose.pose.position.z = 0.0
        odom.pose.pose.orientation = q

        # Twist aproximado
        # (solo referencia rápida)
        avg_rpm = (rpm_l + rpm_r) / 2.0
        odom.twist.twist.linear.x = avg_rpm
        odom.twist.twist.angular.z = 0.0

        self.odom_pub.publish(odom)

        # =============== TF ==================
        t = TransformStamped()

        t.header.stamp = now.to_msg()
        t.header.frame_id = self.frame_id
        t.child_frame_id = self.child_frame

        t.transform.translation.x = x
        t.transform.translation.y = y
        t.transform.translation.z = 0.0

        t.transform.rotation.x = 0.0
        t.transform.rotation.y = 0.0
        t.transform.rotation.z = q.z
        t.transform.rotation.w = q.w

        self.tf_broadcaster.sendTransform(t)


# ==========================================================
def main(args=None):

    rclpy.init(args=args)

    node = SerialOdomNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()