#!/usr/bin/env python3
"""
teleop_keyboard.py  –  ROS2 Jazzy
Comportamiento:
  - Tecla presionada  -> mueve
  - Sin tecla         -> publica cero (para el robot)
  - Publica a 20 Hz   -> watchdog Arduino (500ms) nunca se dispara
  - Hilo separado     -> rclpy.spin() nunca se bloquea
"""

import sys
import select
import termios
import tty
import threading

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist


LIN_VEL    = 0.20   # m/s
ANG_VEL    = 1.20   # rad/s
PUBLISH_HZ = 20     # Hz  — período 50ms, watchdog Arduino es 500ms


BANNER = """
=========================================
 TELEOP ROBOT RECOLECTOR (ROS2 JAZZY)
=========================================

        w
   a    s    d
        x

w / x / a / d : mover  (solo mientras se presiona)
s             : parada de emergencia
CTRL+C        : salir
=========================================
"""


class TeleopKeyboard(Node):

    def __init__(self):
        super().__init__('teleop_keyboard')
        self.pub   = self.create_publisher(Twist, '/cmd_vel', 10)
        self._lock = threading.Lock()
        self._lin  = 0.0
        self._ang  = 0.0
        self.create_timer(1.0 / PUBLISH_HZ, self._publish_loop)

    def set_vel(self, lin: float, ang: float):
        with self._lock:
            self._lin = lin
            self._ang = ang

    def _publish_loop(self):
        with self._lock:
            lin = self._lin
            ang = self._ang
        msg = Twist()
        msg.linear.x  = float(lin)
        msg.angular.z = float(ang)
        self.pub.publish(msg)


def keyboard_thread(node: TeleopKeyboard, settings):
    try:
        while rclpy.ok():
            tty.setraw(sys.stdin.fileno())
            rlist, _, _ = select.select([sys.stdin], [], [], 0.05)

            if rlist:
                key = sys.stdin.read(1)
            else:
                key = ''

            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)

            if   key == 'w':  node.set_vel( LIN_VEL,  0.0)
            elif key == 'x':  node.set_vel(-LIN_VEL,  0.0)
            elif key == 'a':  node.set_vel( 0.0,  ANG_VEL)
            elif key == 'd':  node.set_vel( 0.0, -ANG_VEL)
            elif key == 's':  node.set_vel( 0.0,  0.0)
            elif key == '\x03': break
            else:
                # Sin tecla o tecla desconocida -> parar
                node.set_vel(0.0, 0.0)

    finally:
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)


def main():
    settings = termios.tcgetattr(sys.stdin)
    rclpy.init()
    node = TeleopKeyboard()
    print(BANNER)

    t = threading.Thread(target=keyboard_thread, args=(node, settings), daemon=True)
    t.start()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.set_vel(0.0, 0.0)
        import time; time.sleep(0.15)
        node.destroy_node()
        rclpy.shutdown()
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)


if __name__ == '__main__':
    main()